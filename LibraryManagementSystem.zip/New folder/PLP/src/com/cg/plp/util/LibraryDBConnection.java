package com.cg.plp.util;

import com.cg.plp.exception.LibraryException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class LibraryDBConnection 
{
		private static Properties properties= new Properties();
		private static Connection connection;

		public static Connection getConnection() throws LibraryException
		{
			try {
				InputStream inputStream =new FileInputStream("resources/jdbc.properties");
				properties.load(inputStream);
				String url=properties.getProperty("url");
				String user=properties.getProperty("user");
				String password=properties.getProperty("password");
				inputStream.close();
				
				//DriverManager.registerDriver(new oracle.jdbc.OracleDriver()); 
				connection = DriverManager.getConnection(url, user, password);
				
			} catch (FileNotFoundException e) {
				throw new LibraryException("Could not Find properties file to connect to database.");
			} catch (IOException e) {
				throw new LibraryException("Could not read the database details from properties file.");
			} catch (SQLException e) {
				throw new LibraryException("Database connection problem.");
			}
			return connection;
		}
}
