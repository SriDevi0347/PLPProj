package com.cg.plp.dao;

public interface IQueryMapper
{
	public static final String INSERTUSER="INSERT INTO UserTable VALUES (user_id_seq.NEXTVAL,?,?,?,?,?,?,?)";
	public static final String ADDUSER="INSERT INTO BooksRegistration VALUES(registration_seq.NEXTVAL,?,?,SYSDATE)";
	public static final String BOOKAVAILABILITY="SELECT no_of_copies FROM BooksInventory WHERE book_id=?";
	
	public static final String INSERTBOOK="INSERT INTO BooksInventory VALUES (?,?,?,?,?,?,?)";
	public static final String DELETEBOOK="DELETE FROM BooksInventory WHERE book_id=?";
}
