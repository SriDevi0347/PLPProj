package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.BookTransactionBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.util.LibraryDBConnection;


public class LibraryDoaImpl implements ILibraryDao
{
	public String getName(String id) throws LibraryException
	{
		String name=null;
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT name FROM UserTable WHERE userid=?");
			preparedStatement.setString(1,id);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
				name=resultSet.getString(1);
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}
		return name;
	}
	
	
	public int isUserValid(String id,String pwd) throws LibraryException
	{
		int status=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT password FROM UserTable WHERE userid=?");
			preparedStatement.setString(1,id);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				String pass=resultSet.getString("password");
				if(pass.equals(pwd))
				{
					preparedStatement=connection.prepareStatement("select librarian from UserTable where userid=?");
					preparedStatement.setString(1,id);
					resultSet=preparedStatement.executeQuery();
					resultSet.next();
					String lib=resultSet.getString(1);
					if(lib.equals("Y"))
						status=1;
					else
						status=2;
				}
				else
				{
					System.out.println("Incorrect password.Please enter a valid password");
					status=0;
				}
			}
			else
			{
				System.out.println("Incorrect userid.Please enter a valid userid");
				status=0;
			}
			preparedStatement.close();
			resultSet.close();
			return status;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
	}
	
	
	public int isBookAvailable(String bookid) throws LibraryException
	{
		
		int status=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.BOOKAVAILABILITY);
			preparedStatement.setString(1,bookid);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				int copies=resultSet.getInt("no_of_copies");
				if(copies>0)
				{
					status=1;
				}
				else
				{
					status=2;
				}
			}
			else
				status=3;
			return status;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
	}
	
	
	public int addRequest(String userId, String bookId) throws LibraryException
	{
		int registrationId=0;
		String bookIdTemp=null;
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT book_id FROM booksregistration WHERE user_id=?");
			preparedStatement.setString(1,userId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				bookIdTemp=resultSet.getString(1);
				if(bookId.equals(bookIdTemp))
				{
					registrationId=0;
					return registrationId;
				}
			}
				
			preparedStatement = connection.prepareStatement(IQueryMapper.ADDUSER);
			preparedStatement.setString(1,bookId);
			preparedStatement.setString(2,userId);
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement=connection.prepareStatement("SELECT registration_seq.CURRVAL FROM DUAL");
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			registrationId=rs.getInt(1);
			
			//System.out.println("User id is:"+registrationId);
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
		return registrationId;
	}


	@Override
	public int registerUserDao(UserBean userBean) throws LibraryException
	{
		int userId=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERTUSER);
			preparedStatement.setString(1,userBean.getPassword());
			preparedStatement.setString(2,userBean.getName());
			preparedStatement.setString(3,userBean.getEmailId());
			preparedStatement.setString(4,userBean.getAddress());
			preparedStatement.setString(5,userBean.getGender());
			preparedStatement.setString(6,userBean.getPhoneNum());
			preparedStatement.setString(7,userBean.getLibrarian());
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement=connection.prepareStatement("SELECT user_id_seq.CURRVAL FROM DUAL");
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			userId=rs.getInt(1);
			
			//System.out.println("User id is:"+userId);
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		
		return userId;
	}


	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException 
	{
		boolean status=false;
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERTBOOK);
			preparedStatement.setString(1,bookBean.getBookId());
			preparedStatement.setString(2,bookBean.getBookName());
			preparedStatement.setString(3,bookBean.getAuthor1());
			preparedStatement.setString(4,bookBean.getAuthor2());
			preparedStatement.setString(5,bookBean.getPublisher());
			preparedStatement.setString(6,bookBean.getYearOfPublication());
			preparedStatement.setInt(7,bookBean.getNoOfCopies());
			preparedStatement.executeUpdate();
			connection.commit();
			status=true;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		return status;
	}


	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		boolean status=false;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.DELETEBOOK);
			preparedStatement.setString(1, bookId);
			preparedStatement.executeUpdate();
			connection.commit();
			status=true;
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		return status;
	}


	@Override
	public int returnBook(String transactionId, String bookId) throws LibraryException
	{
		int fine=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		try
		{
			preparedStatement=connection.prepareStatement("update booktransaction set return_date=SYSDATE where transaction_id=?");
			preparedStatement.setString(1, transactionId);
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement=connection.prepareStatement("update booksInventory set no_of_copies=no_of_copies+1 where book_id=?");
			preparedStatement.setString(1, bookId);
			preparedStatement.executeUpdate();
			connection.commit();
			
			
			preparedStatement=connection.prepareStatement("select issue_date,return_date from booktransaction where transaction_id=?");
			preparedStatement.setString(1, transactionId);
			resultSet=preparedStatement.executeQuery();
			resultSet.next();
			Date issueDate=resultSet.getDate(1);
			Date returnDate=resultSet.getDate(2);
			
			int days=(int) ((issueDate.getTime()-returnDate.getTime())/(1000*60*60*24));
			
			if(days>30)
				fine=(days-30)*2;
			
			preparedStatement=connection.prepareStatement("update booktransaction set fine=? where transaction_id=?");
			preparedStatement.setInt(1, fine);
			preparedStatement.setString(2, transactionId);
			preparedStatement.executeUpdate();
			connection.commit();
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		return fine;
	}


	@Override
	public ArrayList displayRequests() throws LibraryException
	{
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		ArrayList<BookRegistrationBean> array=new ArrayList<BookRegistrationBean>();
		
		try
		{
			preparedStatement = connection.prepareStatement("select * from booksregistration order by registration_id");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookRegistrationBean bean=new BookRegistrationBean();
				bean.setRegistrationId(resultSet.getString(1));
				bean.setBookId(resultSet.getString(2));
				bean.setUserId(resultSet.getString(3));
				bean.setRegistrationDate(resultSet.getString(4));
				
				array.add(bean);
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in displaying registered books");
			}
		}
		return array;
	}


	@Override
	public String grantBook(String registrationid, String bookId) throws LibraryException
	{
		String transactionId=null;
		int copies=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		System.out.println("book id: "+bookId);
		
		try
		{
			preparedStatement=connection.prepareStatement("select no_of_copies from booksInventory where book_id=?");
			preparedStatement.setString(1, bookId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
				copies=resultSet.getInt(1);
			System.out.println("copies :"+copies);
			if(copies>=1)
			{
				preparedStatement = connection.prepareStatement("insert into booktransaction(transaction_id,registration_id,issue_date) values (transaction_seq.nextval,?,sysdate)");
				preparedStatement.setString(1, registrationid);
				preparedStatement.executeUpdate();
				connection.commit();
				
				preparedStatement=connection.prepareStatement("select transaction_seq.currval from dual");
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next())
					transactionId=resultSet.getString(1);
				System.out.println("transaction ids "+transactionId);
				
				preparedStatement=connection.prepareStatement("delete from booksregistration where registration_id=?");
				preparedStatement.setString(1, registrationid);
				preparedStatement.executeUpdate();
				
				preparedStatement=connection.prepareStatement("update booksInventory set no_of_copies=no_of_copies-1 where book_id=?");
				preparedStatement.setString(1, bookId);
				preparedStatement.executeUpdate();
				connection.commit();
				
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		return transactionId;
	}

}
