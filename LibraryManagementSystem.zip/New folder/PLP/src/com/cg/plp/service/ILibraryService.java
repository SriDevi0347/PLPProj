package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookTransactionBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;

public interface ILibraryService 
{
	/*public abstract boolean isNameValid(String username);
	public abstract boolean isEmailValid(String emailid);
	public abstract boolean isPasswordValid(String password);
	public abstract boolean IsPhnNumberValid(String mobileNumber);*/
	
	public abstract int isUserValid(String id,String pwd) throws LibraryException;
	public abstract int isBookAvailable(String bookid) throws LibraryException;
	public abstract int addRequest(String userId, String bookId) throws LibraryException;
	
	public abstract int registerUser(UserBean userBean) throws LibraryException;
	public abstract boolean addBooks(BookBean bookBean) throws LibraryException;
	public abstract boolean removeBook(String bookId) throws LibraryException;
	public abstract int returnBook(String transactionId, String bookId) throws LibraryException;
	public abstract ArrayList displayRequests()  throws LibraryException;
	public abstract String grantBook(String registrationid, String bookId) throws LibraryException;
	public abstract String getName(String id) throws LibraryException;
}
