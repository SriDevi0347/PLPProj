package com.cg.plp.exception;

public class LibraryException extends Exception
{
	private static final long serialVersionUID = 1L;
	public LibraryException(String msg)
	{
		System.out.println(msg);;
	}

}
